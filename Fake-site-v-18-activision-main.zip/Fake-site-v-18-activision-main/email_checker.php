<?php
/* Coded By 'kiya' */
session_start();
function getUserIp() {
    if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ipList[0]);
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    $ipDetails = @json_decode(file_get_contents("http://ipinfo.io/{$ip}/json"));
    $country = $ipDetails->country ?? 'Unknown';
    return [$ip, $country];
}
function escapeMarkdownV2($text) {
    $text = str_replace(['\\', '_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!'],
                        ['\\\\', '\_', '\*', '\[', '\]', '\(', '\)', '\~', '\`', '\>', '\#', '\+', '\-', '\=', '\|', '\{', '\}', '\.', '\!'], $text);
    return $text;
}
$botToken = '8356818555:AAFMC6VDrvxGYyTwG6e48Va97FoRspDXS8w'; // Renew this in BotFather if 401
$chatId = '-1003141943398';
$logoUrl = 'https://1000logos.net/wp-content/uploads/2020/09/Call-of-Duty-Logo-2011.png'; // Valid PNG (tested)
function sendToTelegram($token, $chatId, $text, $photoUrl = null, $keyboard = null) {
    if ($photoUrl) {
        $url = "https://api.telegram.org/bot$token/sendPhoto";
        $data = [
            'chat_id' => $chatId,
            'photo' => $photoUrl,
            'caption' => $text,
            'parse_mode' => 'MarkdownV2'
        ];
        if ($keyboard) $data['reply_markup'] = json_encode($keyboard);
    } else {
        $url = "https://api.telegram.org/bot$token/sendMessage";
        $data = [
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'MarkdownV2'
        ];
        if ($keyboard) $data['reply_markup'] = json_encode($keyboard);
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    $log = "HTTP: $httpCode | Error: $error | Result: $result\n";
    file_put_contents('telegram_log.txt', $log, FILE_APPEND);
    return $result;
}
// Visit log
list($userIp, $userCountry) = getUserIp();
$userIpEsc = escapeMarkdownV2($userIp);
$userCountryEsc = escapeMarkdownV2($userCountry);
$userAgent = escapeMarkdownV2($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown');
$timestamp = date('Y-m-d H:i:s', strtotime('+4 hours'));
$visitText = "🔍 NEW EMAIL CHECK VISIT\n\n🌐 IP: `$userIpEsc`\n🏳️ Country: `$userCountryEsc`\n📱 User Agent: `$userAgent`\n⏰ Timestamp: `$timestamp`\n\nCoded By 'kiya'";
sendToTelegram($botToken, $chatId, $visitText, $logoUrl);
$email = $_GET['email'] ?? null;
if (!$email) {
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'Please provide email: ?email=example@mail.com']);
    exit();
}
$emailEsc = escapeMarkdownV2($email);
$url = "https://s.activision.com/activision/signup/checkEmail";
$post = http_build_query(["email" => $email]);
$headers = [
    "Host: s.activision.com",
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
    "Accept: */*",
    "Accept-Language: en-US,en;q=0.5",
    "Content-Type: application/x-www-form-urlencoded; charset=UTF-8",
    "X-Requested-With: XMLHttpRequest",
    "Origin: https://s.activision.com",
    "Connection: keep-alive",
    "Sec-Fetch-Dest: empty",
    "Sec-Fetch-Mode: cors",
    "Sec-Fetch-Site: same-origin",
    "Accept-Encoding: gzip, deflate"
];
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $url,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $post,
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "gzip, deflate",
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_TIMEOUT => 30
]);
$res = curl_exec($ch);
$curlError = curl_error($ch);
curl_close($ch);
if ($curlError) {
    $errorText = "❌ EMAIL CHECK FAILED\n\n📧 Email: `$emailEsc`\n🔴 Error: `$curlError`\n\n🌐 IP: `$userIpEsc`\n🏳️ Country: `$userCountryEsc`\n⏰ Timestamp: `$timestamp`\n\nCoded By 'kiya'";
    sendToTelegram($botToken, $chatId, $errorText, $logoUrl);
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'CURL Error: ' . $curlError]);
    exit();
}
$data = json_decode($res, true);
if (!$data || !isset($data["status"])) {
    $errorText = "❌ EMAIL CHECK INVALID RESPONSE\n\n📧 Email: `$emailEsc`\n🔴 Response: `$res`\n\n🌐 IP: `$userIpEsc`\n🏳️ Country: `$userCountryEsc`\n⏰ Timestamp: `$timestamp`\n\nCoded By 'kiya'";
    sendToTelegram($botToken, $chatId, $errorText, $logoUrl);
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'Invalid response.']);
    exit();
}
$status = $data["status"];
$message = "";
$emoji = "";
if ($status === "invalid") {
    $message = $data["exceptionMessageList"][0] ?? "Email already exists.";
    $emoji = "✅";
    $statusText = "REGISTERED (Invalid for signup)";
} elseif ($status === "valid") {
    $message = "This email address is NOT registered.";
    $emoji = "❌";
    $statusText = "NOT REGISTERED (Valid for signup)";
} else {
    $message = "Unknown status: " . $status;
    $emoji = "⚠️";
    $statusText = "UNKNOWN";
}
// Send result to Telegram
$checkText = "{$emoji} EMAIL CHECK RESULT\n\n📧 Email: `$emailEsc`\n📊 Status: `$statusText`\n📝 Message: `$message`\n\n🌐 IP: `$userIpEsc`\n🏳️ Country: `$userCountryEsc`\n📱 User Agent: `$userAgent`\n⏰ Timestamp: `$timestamp`\n\nCoded By 'kiya'";
sendToTelegram($botToken, $chatId, $checkText, $logoUrl);
// Output JSON for JS
header('Content-Type: application/json');
echo json_encode(['status' => $status, 'message' => $message]);
/* Coded By 'kiya' */
?>